(function (Drupal) {
  Drupal.behaviors.mytheme = {
    attach(context) {
      context
        .querySelectorAll(".mytheme-webform .form-item")
        .forEach((fieldGroup) => {
          const label = fieldGroup.querySelector("label");
          const field = fieldGroup.querySelector(
            'input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]):not([type="submit"]), select, textarea',
          );

          if (!label || !field) {
            return;
          }

          if (field.type === "tel") {
            field.setAttribute("inputmode", "tel");
            if (field.getAttribute("autocomplete") === "off") {
              field.setAttribute("autocomplete", "tel");
            }
          }

          if (field.hasAttribute("placeholder")) {
            return;
          }

          const requiredMark = label.querySelector(".form-required")
            ? " *"
            : "";
          field.setAttribute(
            "placeholder",
            `${label.textContent.trim()}${requiredMark}`,
          );
        });
    },
  };
})(Drupal);
